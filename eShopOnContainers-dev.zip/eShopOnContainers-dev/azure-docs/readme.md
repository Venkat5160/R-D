# Azure Related Documentation

## Builds and releases

1. [VSTS build for Xamarin App (Android)](builds/xamarin-android.md)
2. [VSTS build for Xamarin App (iOS)](builds/xamarin-iOS.md)
