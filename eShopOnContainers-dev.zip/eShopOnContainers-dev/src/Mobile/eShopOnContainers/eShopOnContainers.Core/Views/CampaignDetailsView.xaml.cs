﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views
{
    public partial class CampaignDetailsView : ContentPage
    {
        public CampaignDetailsView()
        {
            InitializeComponent();
        }
    }
}
