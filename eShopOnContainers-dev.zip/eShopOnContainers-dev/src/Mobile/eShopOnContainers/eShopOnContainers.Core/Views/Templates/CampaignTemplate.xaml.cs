﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views.Templates
{
    public partial class CampaignTemplate : ContentView
    {
        public CampaignTemplate()
        {
            InitializeComponent();
        }
    }
}