﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views.Templates
{
    public partial class OrderTemplate : ContentView
    {
        public OrderTemplate()
        {
            InitializeComponent();
        }
    }
}