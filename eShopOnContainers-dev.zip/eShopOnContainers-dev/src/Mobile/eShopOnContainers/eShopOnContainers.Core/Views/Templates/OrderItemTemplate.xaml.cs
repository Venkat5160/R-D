﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views.Templates
{
    public partial class OrderItemTemplate : ContentView
    {
        public OrderItemTemplate()
        {
            InitializeComponent();
        }
    }
}