﻿namespace eShopOnContainers.Core.Models.User
{
    public class LogoutParameter
    {
        public bool Logout { get; set; }
    }
}
