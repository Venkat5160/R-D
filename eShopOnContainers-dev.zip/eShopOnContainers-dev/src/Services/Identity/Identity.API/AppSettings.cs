﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eShopOnContainers.Identity
{
    public class AppSettings
    {
        public string MvcClient { get; set; }
        public bool UseCustomizationData { get; set; }
    }
}
