﻿namespace GracePeriodManager.Services
{
    public interface IManagerService
    {
        void CheckConfirmedGracePeriodOrders();
    }
}